#include "item.h"
Item *NewVettore(int);
void printVettore(Item*, int);
void SelectionSort(Item *,int);
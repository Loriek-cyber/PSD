typedef struct song *Song;
Song InnitSong();
char *getTitle(Song);
char *getArtist(Song);
int getDuration(Song);